const express = require('express')
const bodyParser = require('body-parser')
const path = require('path')
const firebase = require('firebase')

const app = express()

app.set('view engine', 'hbs')
app.set('views', path.join(__dirname, 'views'))

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));


var config = {
    apiKey: "AIzaSyCIaRj0aItr82G-WFunlFGtFaSLN-CkeD8",
    authDomain: "intern-basdat.firebaseapp.com",
    databaseURL: "https://intern-basdat.firebaseio.com",
    projectId: "intern-basdat",
    storageBucket: "intern-basdat.appspot.com",
    messagingSenderId: "480541785640"
  };
  firebase.initializeApp(config);


var database = firebase.database();
  
app.post('/addData', (req,res) => {
    console.log(req.body);
    data = req.body

    key = database.ref().child('posts').push().key;

    database.ref('Person/' + data.name).set({
        name    : data.name,
        age     : data.age
    })
    res.render('index')
})

app.get('/input', (req,res) => {
    database.ref("Person").once('value', (snapshot) => {
        // console.log(snapshot.val());
        data = snapshot.val();
        // snapshot.forEach((data) => {
        //     console.log(data.key);
        // })
        res.render('input', {
            data : data
        })
    })
})

app.post('/delete', (req,res) => {
    console.log(req.body.del);
    data = req.body.del;

    ref = database.ref('Person/' + data);
    ref.remove()
    res.redirect('/input')
})

// app.post('/input', (req,res) => {
//     console.log(req.body);
//     console.log(req.body.nama);
    
//     res.render('input.hbs', {
//         nama: req.body.nama,
//         nim: req.body.nim
//     })
// })

// bit.ly/product-intern1



app.get("/", (req,res) => {
    res.render('index.hbs')
})
app.get('*', (req,res) => {
    res.send('Page not Found')
})
app.listen(3000, () => {
    console.log("Server on Port 3000.....");
})